<?php
/* Match classes? */
/* wordpress-start
<!-- wp:columns -->
<div class="wp-block-columns"
    ><!-- wp:column {"width":"50%"} -->
    <div class="wp-block-column" style="flex-basis:50%">
        <!-- wp:post-featured-image /-->
    </div>
    <!-- /wp:column -->

    <!-- wp:column {"width":"50%"} -->
    <div class="wp-block-column" style="flex-basis:50%">
        <!-- wp:post-title /-->

        <!-- wp:post-excerpt /-->
    </div>
    <!-- /wp:column --></div>
<!-- /wp:columns -->
wordpress-end */
